import { Injectable, NestMiddleware, Logger } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  private logger = new Logger(LoggerMiddleware.name);

  use(req: Request, res: Response, next: NextFunction) {
    const startTimestamp = Date.now();
    const requestMethod = req.method;
    const originURL = req.url || req.originalUrl;
    const httpVersion = `HTTP/${req.httpVersion}`;
    const userAgent = req.headers['user-agent'];
    const ipAddress = req.socket.remoteAddress;

    if (!ipAddress) return next();

    res.on('finish', () => {
      const statusCode = res.statusCode;
      const endTimestamp = Date.now() - startTimestamp;

      this.logger.log(
        `${ipAddress} (${userAgent}) - "${requestMethod} ${originURL} ${httpVersion}" ${statusCode} +${endTimestamp}ms`,
      );

      const body = req.body ?? {};
      if (Object.keys(body).length > 0)
        this.logger.log(`Request Body: ${JSON.stringify(body)}`);
    });
    next();
  }
}
